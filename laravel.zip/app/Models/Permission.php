<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{

    //Permission.php
    public function roles() {
        return $this->belongsToMany(Role::class,'roles_permissions');
    }

//    All Permissions List

    public function allPermissions(){

        $all_permissions = Permission::leftJoin('roles_permissions', function($join) {
            $join->on('permissions.id', '=', 'roles_permissions.permission_id');
        })
            ->get();

        return $all_permissions;
    }

    public function scopeAllPermissionToRoles($query){

        return $query->leftjoin('roles.id', '=', 'roles_permissions.role_id');

    }
}
