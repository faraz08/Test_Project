<?php
namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use App\Models\Patient;
use function foo\func;

class Cases extends Model
{
    protected $table = 'cases';
//    public $timestamps = false;

    protected $fillable = ['case_number', 'patient_name', 'doctor_name', 'user_id', 'portal_id'];


//    public function patients(){
//        return $this->belongsTo('App\Models\Patient', 'patient_id', 'id' );
//    }

    public function patients(){

        return $this->hasMany('App\Models\Patient', 'case_id', 'id' );
    }

    public function storePatientCase($caseInputData){

        $case = Cases::create($caseInputData);
        return $case;
    }

//    public function getCreatedAtAttribute($date)
//    {
//        return Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('Y-m-d');
//    }


}
