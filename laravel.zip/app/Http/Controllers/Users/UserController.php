<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Http\Middleware\RoleMiddleware;
use App\Models\Permission;
use App\Models\Role;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{

    public function __construct()
    {
//        $this->middleware('role');
    }

    public function index()
    {

        $user = new User();

        $user_id = Auth::id();

        $admin_user = $user->isAdmin();


        if (!$admin_user) {

            $data['getUserRoles'] = User::with('roles', 'permissions')->where('users.id', $user_id)->get();

        } elseif ($admin_user) {

            $data['getUserRoles'] = $user->getUserWithRoles();
        }

        $data['status'] =  array('Active', 'Inactive', 'Blocked');

        $loggedInUser = Auth::user();
        $user_has_role = $loggedInUser->hasRole( ['developer']);

//        dd($user_has_role);
        return view('users.users_list', $data);
    }

    public function editPermissions($slug)
    {
        $user = new User();
        $data['user'] = User::where('name', $slug)->first();

        $data['getUserRoles'] = User::with('roles')->where('id', $data['user']->id)->get();

//        $data['getUserRoles'] = $user->getUserWithRoles();
        $data['all_permissions'] = Permission::all();
        $data['all_roles'] = Role::all();

        $permissons = new Permission();
        $data['all_permissions'] = $permissons->allPermissions();

        $roles = new Role();
        $data['all_roles'] = $roles->allRoles();

        return view('users.edit_user_permissions', $data);
    }

    public function editUserPermissions(Request $request){

        $user_name = $request->input('user');
        $role = $request->input('roles');
        $permissions_list = $request->input('permissions');
        $user_perm = Permission::whereIn('slug', $permissions_list)->pluck('id');


       $role_id = Role::find($role);
       if($role_id){
           $destroy = DB::table('roles_permissions')->whereIn('role_id', $role_id)->delete();

           if($destroy){

               $user_data = User::where('name', $user_name)->first();
               $user_data->roles()->attach($role);
               foreach ($user_perm as $permission){
                   $user_data->permissions()->attach($permission);
               }
//               foreach ($user_perm as $permission_id){
//                   $data = DB::table('roles_permissions')->insert(['role_id' => $role, 'permission_id'=> $permission_id]);
//               }
           }
//           DB::table('roles_permissions')->whereIn('permission_id', $role_id)->delete();

       }

    }

    public function createRolePermissions(Request $request)
    {

        $user_name = $request->input('user');
        $role = $request->input('roles');
        $permissions = $request->input('permissions');

        $user_role = Role::where('id', $role)->first();
        $user_data = User::where('name', $user_name)->first();
        $user_perm = Permission::where('slug', $permissions)->get();

        $user_data->roles()->attach($user_role);
        $user_data->permissions()->attach($user_perm);
    }

    public function userStatusChange(Request $request){

        $user_id = $request->input('user_id');
        $status = $request->input('status');

        $user = User::find($user_id);
        $user->status = $status;
        $user->save();

        return redirect('users');

    }

    public function deleteUser(Request $request){

        $id = $request->input('id');

        $success = DB::table('users')->delete($id);

        return $success;

    }
}
