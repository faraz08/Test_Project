<?php

namespace App\Http\Controllers\Cases;

use App\Http\Controllers\Controller;
use App\Http\Requests\CaseStoreValidationRequest;
use App\Models\Cases;
use App\Models\Patient;
use App\Models\Permission;
use App\Models\Portal;
use App\Models\Role;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use Illuminate\View\View;
use Validator;
use Session;
use function Ramsey\Uuid\v1;

class CaseController extends Controller
{
    public function __construct()
    {
        $this->middleware('role');
    }

    public function index()
    {
        $data['portal'] = Portal::all();

        return view('case', $data);
    }

    public function caseSubmit(Request $request)
    {
//        $check_case = Validator::make($request->all(), [
//            'case_number' => 'required|unique:cases'
//        ]);


//        if($check_case->fails()){
//
//            return response()->json($check_case->messages(), 422);
////            return response()->json(array(
////                'success' => false,
////                'errors' => $validator->getMessageBag()->toArray()
////
////            ), 422);
//
//        }


        $case_number = $request->input('case_number');
        $patient_name = $request->input('patient_name');
        $doctor_name = $request->input('doctor_name');
        $portal_id = $request->input('portal_id');
        $date = date("Y-m-d H:m:s");
        $user_id = Auth::id();

        $caseifExist = Cases::where('case_number', "$case_number")->first();

        if ($caseifExist != null) {
            $caseId = $caseifExist->id;
            $caseNumber = $caseifExist->case_number;

            $number_of_patients = Cases::find($caseId)->patients;

            $revisions = count($number_of_patients) + 1;

        } elseif ($caseifExist == null) {

            $revisions = 0;
            $caseInputData = ['patient_name' => $patient_name,
                'doctor_name' => $doctor_name,
                'case_number' => $case_number,
                'created_at' => $date,
                'user_id' => $user_id,
                'portal_id' => $portal_id
            ];

            $case = new Cases();

            $case_data = $case->storePatientCase($caseInputData);
            $caseId = $case_data->id;
            $caseNumber = $case_data->case_number;
        }

        if ($caseId != null && $caseId > 0) {
            $filesBefore = $request->file('file_before');

            $no_of_files_attached = count($filesBefore);
            $files_array = array();
            foreach ($filesBefore as $fileBefore) {

                $fileName = $fileBefore->getClientOriginalName();

                $pathToStoreFile = public_path() . '/cases/' . $caseNumber . '/filesBefore/' . $revisions;

                $fileBefore->move($pathToStoreFile, $fileName);

                $files_array[] = $fileName;

            }

            $filesAfter = $request->file('file_after');

            $no_of_files_attached = count($filesAfter);
            $afterfileArray = array();
            foreach ($filesAfter as $fileAfter) {

                $afterfileName = $fileAfter->getClientOriginalName();

                $pathToStoreFile = public_path() . '/cases/' . $caseNumber . '/filesAfter/' . $revisions;

                $fileAfter->move($pathToStoreFile, $afterfileName);

                $afterfileArray[] = $afterfileName;

            }

            $iprForm = $request->file('ipr_form');
            $ipr_form = $iprForm->getClientOriginalName();

            $pathToStoreFile = public_path() . '/cases/' . $caseNumber . '/ipr_form/' . $revisions;

            $iprForm->move($pathToStoreFile, $ipr_form);

            $unique_url = URL::to('/').'/'.$case_number.'/'.uniqid();

            $data_array = [

                'case_id' => $caseId,
                'operator_name' => $request->input('operator_name'),
                'status' => $request->input('status'),
                'upper_aligner' => $request->input('upper_aligner'),
                'lower_aligner' => $request->input('lower_aligner'),
                'file_before' => json_encode($files_array),
                'file_after' => json_encode($afterfileArray),
                'ipr_form' => $ipr_form,
                'updated_at' => null,
                'created_at' => $date,
                'revisions' => $revisions,
                'url' => $unique_url,
            ];

            $patient = new Patient();
            $patientId = $patient->storePatient($data_array);
            if ($patientId) {
                Session::flash('success', 'Case ' .$case_number .' has been created successfully!');
                return view('partials.flash-messages');
            }
        }
    }

    public function caseList()
    {

        $user = new User();
        $isAdmin = $user->isAdmin();

        $loggedIn = Auth::id();

        $cases = Cases::with('patients')
            ->when(!$isAdmin, function ($query) use ($loggedIn) {
                return $query->where('user_id', $loggedIn);
            })->get();

        $data['cases'] = $cases;

        return view('case_list', $data);
    }

    public function getCaseNumbers(Request $request)
    {

        $search_term = $request->input('query');

        $data['case_numbers'] = Cases::where('case_number', 'LIKE', '%'. $search_term . '%')->get();

        $returnHTML = view('ajaxViews.cases.case_numbers_list', $data)->render();
        return response()->json(array('success' => true, 'html' => $returnHTML));

    }

    public function getCasesData(Request $request)
    {

        $case_number = $request->input('case_number');

        $case = Cases::where('case_number', "$case_number")->first();

        if (!$case) {
            return false;
        } else {
            return $case;
        }
    }

    public function getPatientRevisionModal(Request $request)
    {

        $patient_id = $request->input('id');

        $data['patient'] = Patient::with('cases')->where('id', $patient_id)->first();

        $returnHTML = view('ajaxViews.cases.case_revision_edit', $data)->render();
        return response()->json(array('success' => true, 'html' => $returnHTML));

    }

    public function deletePatientRevision(Request $request)
    {

        $patient_id = $request->input('id');
        $del_patient = Patient::where('id', $patient_id)->delete();

    }

    public function deleteCase(Request $request)
    {

        $case_id = $request->input('id');

        $cases = Cases::with('patients')->where('id', $case_id)->first();

        $deleted_patients = $cases->patients->pluck('case_id');
        $cases->patients()->delete();
        Patient::destroy($deleted_patients);
        $cases->delete();

        dd($deleted_patients);

    }

    public function showPatientModal(Request $request)
    {

        $patient_id = $request->input('id');

        $data['patient'] = Patient::with('cases')->where('id', $patient_id)->first();

        $data['files_before'] = $data['patient']->file_before;

        $returnHTML = view('ajaxViews.cases.case_revision_show', $data)->render();
        return response()->json(array('success' => true, 'html' => $returnHTML));

    }

    public function showPatientListModal(Request $request)
    {

        $case_id = $request->input('id');


        $data['patients'] = Patient::where('case_id', $case_id)->get();

        $returnHTML = view('ajaxViews.cases.patient_list', $data)->render();
        return response()->json(array('success' => true, 'html' => $returnHTML));
    }

    public function getRolesAjaxCall(Request $request)
    {

        $role_id = $request->input('query');

        $permissions = Role::with('permissions')->where('id', $role_id)->get();

        return $permissions;

//        dd($permissions);
//        $permissions = Permission::getPermissionToRoles()->where('id', $role_id)->get();

//        $permissions = Role::where('id', $role_id)
//            ->leftJoin('id', '=', 'roles_permissions.role_id')
//            ->get();

//        $permissions = Role::leftJoin('roles_permissions', function ($query, $role_id){
//            $query->where('roles.id', $role_id);
//        })->get();

//        dd($permissions);

    }

    public function caseNumberSearch(Request $request){

        $search = $request->input('query');

        $data = Cases::where('case_number', 'LIKE', '%'. $search. '%')->select('case_number')->get();

        return response()->json($data);

    }

}
